python3 main.py > out.out
python3 -m cProfile main.py > debug.out # profile