void calcProb(int , long long[],int, long long, int);
int onePair(long long, long long);
int twoPair(long long, long long );
int triple(long long, long long );
int straight(long long, long long);
int flush(long long, long long );
int fullhouse(long long, long long );
int fourCard(long long, long long );
int straightFlush(long long, long long );
