int getPlayer(int*);
void hallcard(long long[], const int, long long*);
void poker();
int death(long long[], int, int*);
void tableCard(int, long long*, long long* );
void printGame(long long[], int, int, long long);
void printCard(long long);
void printProb(long long[], long long, int, int);
