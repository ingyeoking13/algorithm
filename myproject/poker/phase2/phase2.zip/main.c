#include <stdio.h>
#include "iohelper.h"
#include "game.h"

int main(){

    poker();
}
