# poker game
## phase 1
### 1. generate random card
### 2. make decision to continue game
### 3. that's all

# what functions will be implemented during phase 2?
## I'm thinking about two ways.
### 1. calculating probability
#### 1. 1. just for one player. that is, he knows only community card and his own hand.
#### 1. 2. for all player cards. that is, all in mode (case all players know others hands)
### 2. find winner.

### I don't know which one should be built first right now.
