void clrbuf();
char* getUserName(char[15]);
int getIntRange(int, int);
int yes();
void printNewTable();
void printLines(const char* );
void pause();
void printBit(long long, int);
